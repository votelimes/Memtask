package com.example.clock.model;

import androidx.room.Entity;

@Entity(tableName = "task_util_info")
public class TaskUtilInfo {
    private long id;
}
